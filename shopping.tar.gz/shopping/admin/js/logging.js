$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+956411+'&oi='+3+'&ot=1&&url='+window.location, function(json){})    

});