			
			
			
		<div id="site_title">
			<h1>
				<a href="http://www.templatemo.com" rel="nofollow">Online Shoes Store</a>
			</h1>
		</div>
        <div id="header_right">
        	
		</div>
        <div class="cleaner"></div>