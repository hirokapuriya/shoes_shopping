<ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="categories.php">Add Category</a>
                </li>
                <li><a href="upload.php">Upload Products</a>
                </li>
                <li><a href="list.php">Browse</a></li>
                <li><a href="login.php">Logout</a></li>
                
            </ul>
